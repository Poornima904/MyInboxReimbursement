sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("inbox.workflowtask.controller.MyTaskUI",{onInit:function(){}})});
//# sourceMappingURL=MyTaskUI.controller.js.map